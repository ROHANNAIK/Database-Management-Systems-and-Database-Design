-- MySQL dump 10.13  Distrib 5.7.19, for Win64 (x86_64)
--
-- Host: localhost    Database: railway_operations_management
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `age_group_of_passenger_vw`
--

DROP TABLE IF EXISTS `age_group_of_passenger_vw`;
/*!50001 DROP VIEW IF EXISTS `age_group_of_passenger_vw`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `age_group_of_passenger_vw` AS SELECT 
 1 AS `Full_name`,
 1 AS `email_id`,
 1 AS `PNR`,
 1 AS `Gender`,
 1 AS `Age`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cancellations`
--

DROP TABLE IF EXISTS `cancellations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cancellations` (
  `train_id` int(11) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `PNR` varchar(20) NOT NULL,
  `date_cancelled` date NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`train_id`,`email_id`,`PNR`),
  KEY `rstatus_ibfk_1` (`email_id`),
  CONSTRAINT `rstatus_ibfk_1` FOREIGN KEY (`email_id`) REFERENCES `passenger` (`email_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cancellations`
--

LOCK TABLES `cancellations` WRITE;
/*!40000 ALTER TABLE `cancellations` DISABLE KEYS */;
INSERT INTO `cancellations` VALUES (5,'augue.id@in.ca','7MESYO','2017-12-12','Cancelled');
/*!40000 ALTER TABLE `cancellations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(45) NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'Manufacturing'),(2,'Maintenance'),(3,'Field Services'),(4,'Repairs');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_department before insert on department
for each row
begin
 if new.department_id = '' then
 signal sqlstate '45000';
 elseif
 new.department_name = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `earnings_vs_expense_vw`
--

DROP TABLE IF EXISTS `earnings_vs_expense_vw`;
/*!50001 DROP VIEW IF EXISTS `earnings_vs_expense_vw`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `earnings_vs_expense_vw` AS SELECT 
 1 AS `Zone`,
 1 AS `Total Earnings`,
 1 AS `Total Expense`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `fare_per_journey`
--

DROP TABLE IF EXISTS `fare_per_journey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fare_per_journey` (
  `PNR` varchar(50) DEFAULT NULL,
  `train_id` int(11) DEFAULT NULL,
  `seat_number` varchar(20) DEFAULT NULL,
  `class_type` varchar(20) DEFAULT NULL,
  `Fare` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fare_per_journey`
--

LOCK TABLES `fare_per_journey` WRITE;
/*!40000 ALTER TABLE `fare_per_journey` DISABLE KEYS */;
INSERT INTO `fare_per_journey` VALUES ('9622VU',5,'A13','First',4000),('7MESYO',5,'A32','First',4000);
/*!40000 ALTER TABLE `fare_per_journey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `train_id` int(11) DEFAULT NULL,
  `Number_of_tickets_booked` int(11) DEFAULT NULL,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (5,1,'2017-12-12 05:10:11'),(5,1,'2017-12-12 05:11:11'),(5,1,'2017-12-12 05:12:11'),(5,1,'2017-12-12 05:13:11'),(5,1,'2017-12-12 05:14:11'),(5,1,'2017-12-12 05:15:11'),(5,1,'2017-12-12 05:16:11'),(5,1,'2017-12-12 05:17:11'),(5,1,'2017-12-12 05:18:11'),(5,1,'2017-12-12 05:19:11'),(5,1,'2017-12-12 05:20:11'),(5,1,'2017-12-12 05:21:11'),(5,1,'2017-12-12 05:22:11'),(3,1,'2017-12-12 05:23:11'),(5,1,'2017-12-12 05:23:11'),(3,1,'2017-12-12 05:24:11'),(5,1,'2017-12-12 05:24:11'),(3,1,'2017-12-12 05:25:11'),(5,1,'2017-12-12 05:25:11'),(3,1,'2017-12-12 05:26:11'),(5,1,'2017-12-12 05:26:11'),(3,1,'2017-12-12 05:27:11'),(5,1,'2017-12-12 05:27:11'),(3,1,'2017-12-12 05:28:11'),(5,1,'2017-12-12 05:28:11'),(3,1,'2017-12-12 05:29:11'),(5,1,'2017-12-12 05:29:11'),(3,1,'2017-12-12 05:30:11'),(5,1,'2017-12-12 05:30:11'),(3,1,'2017-12-12 05:31:11'),(5,1,'2017-12-12 05:31:11'),(3,1,'2017-12-12 05:32:11'),(5,1,'2017-12-12 05:32:11'),(3,1,'2017-12-12 05:33:11'),(5,1,'2017-12-12 05:33:11'),(3,1,'2017-12-12 05:34:11'),(5,1,'2017-12-12 05:34:11'),(3,1,'2017-12-12 05:35:11'),(5,1,'2017-12-12 05:35:11'),(3,1,'2017-12-12 05:36:11'),(5,1,'2017-12-12 05:36:11'),(3,1,'2017-12-12 05:37:11'),(5,1,'2017-12-12 05:37:11'),(3,1,'2017-12-12 05:38:11'),(5,1,'2017-12-12 05:38:11'),(3,1,'2017-12-12 05:39:11'),(5,1,'2017-12-12 05:39:11'),(3,1,'2017-12-12 05:40:11'),(5,1,'2017-12-12 05:40:11'),(3,1,'2017-12-12 05:41:11'),(5,1,'2017-12-12 05:41:11'),(3,1,'2017-12-12 05:42:11'),(5,1,'2017-12-12 05:42:11'),(3,1,'2017-12-12 05:43:11'),(5,1,'2017-12-12 05:43:11'),(3,1,'2017-12-12 05:44:11'),(5,1,'2017-12-12 05:44:11'),(3,1,'2017-12-12 05:45:11'),(5,1,'2017-12-12 05:45:11'),(3,1,'2017-12-12 05:46:11'),(5,1,'2017-12-12 05:46:11'),(3,1,'2017-12-12 05:47:11'),(5,1,'2017-12-12 05:47:11'),(3,1,'2017-12-12 05:48:11'),(5,1,'2017-12-12 05:48:11'),(3,1,'2017-12-12 05:49:11'),(5,1,'2017-12-12 05:49:11'),(3,1,'2017-12-12 05:50:11'),(5,1,'2017-12-12 05:50:11'),(3,1,'2017-12-12 05:51:11'),(5,1,'2017-12-12 05:51:11'),(3,1,'2017-12-12 05:52:11'),(5,1,'2017-12-12 05:52:11'),(3,1,'2017-12-12 05:53:11'),(5,1,'2017-12-12 05:53:11'),(3,1,'2017-12-12 05:54:11'),(5,1,'2017-12-12 05:54:11'),(3,1,'2017-12-12 05:55:11'),(5,1,'2017-12-12 05:55:11'),(3,1,'2017-12-12 05:56:11'),(5,1,'2017-12-12 05:56:11'),(3,1,'2017-12-12 05:57:11'),(5,1,'2017-12-12 05:57:11'),(3,1,'2017-12-12 05:58:11'),(5,1,'2017-12-12 05:58:11'),(3,1,'2017-12-12 07:27:20'),(5,1,'2017-12-12 07:27:20'),(3,1,'2017-12-12 07:28:11'),(5,1,'2017-12-12 07:28:11'),(3,1,'2017-12-12 07:29:11'),(5,1,'2017-12-12 07:29:11'),(3,1,'2017-12-12 07:30:11'),(5,1,'2017-12-12 07:30:11'),(3,1,'2017-12-12 07:31:11'),(5,1,'2017-12-12 07:31:11'),(3,1,'2017-12-12 07:32:11'),(5,1,'2017-12-12 07:32:11'),(3,1,'2017-12-12 07:33:11'),(5,1,'2017-12-12 07:33:11'),(3,1,'2017-12-12 07:34:11'),(5,1,'2017-12-12 07:34:11'),(3,1,'2017-12-12 07:35:11'),(5,1,'2017-12-12 07:35:11'),(3,1,'2017-12-12 07:36:11'),(5,1,'2017-12-12 07:36:11'),(3,1,'2017-12-12 07:37:11'),(5,1,'2017-12-12 07:37:11'),(3,1,'2017-12-12 07:38:11'),(5,1,'2017-12-12 07:38:11'),(3,1,'2017-12-12 07:39:11'),(5,1,'2017-12-12 07:39:11'),(3,1,'2017-12-12 07:40:11'),(5,1,'2017-12-12 07:40:11'),(3,1,'2017-12-12 07:41:11'),(5,1,'2017-12-12 07:41:11'),(3,1,'2017-12-12 07:42:11'),(5,1,'2017-12-12 07:42:11'),(3,1,'2017-12-12 07:43:11'),(5,1,'2017-12-12 07:43:11'),(3,1,'2017-12-12 07:44:11'),(5,1,'2017-12-12 07:44:11'),(3,1,'2017-12-12 07:45:11'),(5,1,'2017-12-12 07:45:11'),(3,1,'2017-12-12 07:46:11'),(5,1,'2017-12-12 07:46:11'),(3,1,'2017-12-12 07:47:11'),(5,1,'2017-12-12 07:47:11'),(3,1,'2017-12-12 07:48:11'),(5,1,'2017-12-12 07:48:11'),(3,1,'2017-12-12 07:49:11'),(5,1,'2017-12-12 07:49:11'),(3,1,'2017-12-12 07:50:11'),(5,1,'2017-12-12 07:50:11'),(3,1,'2017-12-12 07:51:11'),(5,1,'2017-12-12 07:51:11'),(3,1,'2017-12-12 07:52:11'),(5,1,'2017-12-12 07:52:11'),(3,1,'2017-12-12 07:53:11'),(5,1,'2017-12-12 07:53:11'),(3,1,'2017-12-12 07:54:11'),(5,1,'2017-12-12 07:54:11'),(3,1,'2017-12-12 07:55:11'),(5,1,'2017-12-12 07:55:11'),(3,1,'2017-12-12 07:56:11'),(5,1,'2017-12-12 07:56:11'),(3,1,'2017-12-12 07:57:11'),(5,1,'2017-12-12 07:57:11'),(3,1,'2017-12-12 07:58:11'),(5,1,'2017-12-12 07:58:11'),(3,1,'2017-12-12 07:59:11'),(5,1,'2017-12-12 07:59:11'),(3,1,'2017-12-12 08:00:11'),(5,1,'2017-12-12 08:00:11'),(3,1,'2017-12-12 08:01:11'),(5,1,'2017-12-12 08:01:11'),(3,1,'2017-12-12 08:02:11'),(5,1,'2017-12-12 08:02:11'),(3,1,'2017-12-12 08:03:11'),(5,1,'2017-12-12 08:03:11'),(3,1,'2017-12-12 08:04:11'),(5,1,'2017-12-12 08:04:11'),(3,1,'2017-12-12 08:05:11'),(5,1,'2017-12-12 08:05:11'),(3,1,'2017-12-12 08:06:11'),(5,1,'2017-12-12 08:06:11'),(3,1,'2017-12-12 08:07:11'),(5,1,'2017-12-12 08:07:11'),(3,1,'2017-12-12 08:08:11'),(5,1,'2017-12-12 08:08:11'),(3,1,'2017-12-12 08:09:11'),(5,1,'2017-12-12 08:09:11'),(3,1,'2017-12-12 08:10:11'),(5,1,'2017-12-12 08:10:11'),(3,1,'2017-12-12 08:11:11'),(5,1,'2017-12-12 08:11:11'),(3,1,'2017-12-12 08:12:11'),(5,1,'2017-12-12 08:12:11'),(3,1,'2017-12-12 08:13:11'),(5,1,'2017-12-12 08:13:11'),(3,1,'2017-12-12 08:14:11'),(5,1,'2017-12-12 08:14:11'),(3,1,'2017-12-12 08:15:11'),(5,1,'2017-12-12 08:15:11'),(3,1,'2017-12-12 08:16:11'),(5,1,'2017-12-12 08:16:11'),(3,1,'2017-12-12 08:17:11'),(5,1,'2017-12-12 08:17:11'),(3,1,'2017-12-12 08:18:11'),(5,1,'2017-12-12 08:18:11'),(3,1,'2017-12-12 08:19:11'),(5,1,'2017-12-12 08:19:11'),(3,1,'2017-12-12 08:20:11'),(5,1,'2017-12-12 08:20:11'),(3,1,'2017-12-12 08:21:11'),(5,1,'2017-12-12 08:21:11'),(3,1,'2017-12-12 08:22:11'),(5,1,'2017-12-12 08:22:11'),(3,1,'2017-12-12 08:23:11'),(5,1,'2017-12-12 08:23:11'),(3,1,'2017-12-12 08:24:11'),(5,1,'2017-12-12 08:24:11'),(3,1,'2017-12-12 08:25:11'),(5,1,'2017-12-12 08:25:11'),(3,1,'2017-12-12 08:26:11'),(5,1,'2017-12-12 08:26:11'),(3,1,'2017-12-12 08:27:11'),(5,1,'2017-12-12 08:27:11'),(3,1,'2017-12-12 08:28:11'),(5,1,'2017-12-12 08:28:11'),(3,1,'2017-12-12 08:29:11'),(5,1,'2017-12-12 08:29:11'),(3,1,'2017-12-12 08:30:11'),(5,1,'2017-12-12 08:30:11'),(3,1,'2017-12-12 08:31:11'),(5,1,'2017-12-12 08:31:11'),(3,1,'2017-12-12 08:32:11'),(5,1,'2017-12-12 08:32:11'),(3,1,'2017-12-12 08:33:11'),(5,1,'2017-12-12 08:33:11'),(3,1,'2017-12-12 08:34:11'),(5,1,'2017-12-12 08:34:11'),(3,1,'2017-12-12 08:35:11'),(5,1,'2017-12-12 08:35:11'),(3,1,'2017-12-12 08:36:11'),(5,1,'2017-12-12 08:36:11'),(3,1,'2017-12-12 08:37:11'),(5,1,'2017-12-12 08:37:11'),(3,1,'2017-12-12 08:38:11'),(5,1,'2017-12-12 08:38:11'),(3,1,'2017-12-12 08:39:11'),(5,1,'2017-12-12 08:39:11'),(3,1,'2017-12-12 08:40:11'),(5,1,'2017-12-12 08:40:11'),(3,1,'2017-12-12 08:41:11'),(5,1,'2017-12-12 08:41:11'),(3,1,'2017-12-12 08:42:11'),(5,1,'2017-12-12 08:42:11'),(3,1,'2017-12-12 08:43:11'),(5,1,'2017-12-12 08:43:11'),(3,1,'2017-12-12 08:44:11'),(5,1,'2017-12-12 08:44:11'),(3,1,'2017-12-12 08:45:11'),(5,1,'2017-12-12 08:45:11'),(3,1,'2017-12-12 08:46:11'),(5,1,'2017-12-12 08:46:11'),(3,1,'2017-12-12 08:47:11'),(5,1,'2017-12-12 08:47:11'),(3,1,'2017-12-12 08:48:11'),(5,1,'2017-12-12 08:48:11'),(3,1,'2017-12-12 08:49:11'),(5,1,'2017-12-12 08:49:11'),(3,1,'2017-12-12 08:50:11'),(5,1,'2017-12-12 08:50:11'),(3,1,'2017-12-12 08:51:11'),(5,1,'2017-12-12 08:51:11'),(3,1,'2017-12-12 08:52:11'),(5,1,'2017-12-12 08:52:11'),(3,1,'2017-12-12 08:53:11'),(5,1,'2017-12-12 08:53:11'),(3,1,'2017-12-12 08:54:11'),(5,1,'2017-12-12 08:54:11'),(3,1,'2017-12-12 08:55:11'),(5,1,'2017-12-12 08:55:11'),(3,1,'2017-12-12 08:56:11'),(5,1,'2017-12-12 08:56:11'),(3,1,'2017-12-12 08:57:11'),(5,1,'2017-12-12 08:57:11'),(3,1,'2017-12-12 08:58:11'),(5,1,'2017-12-12 08:58:11'),(3,1,'2017-12-12 08:59:12'),(5,1,'2017-12-12 08:59:12'),(3,1,'2017-12-12 09:00:11'),(5,1,'2017-12-12 09:00:11'),(3,1,'2017-12-12 09:01:11'),(5,1,'2017-12-12 09:01:11'),(3,1,'2017-12-12 09:02:11'),(5,1,'2017-12-12 09:02:11'),(3,1,'2017-12-12 09:03:11'),(5,1,'2017-12-12 09:03:11'),(3,1,'2017-12-12 09:04:11'),(5,1,'2017-12-12 09:04:11'),(3,1,'2017-12-12 09:05:11'),(5,1,'2017-12-12 09:05:11'),(3,1,'2017-12-12 09:06:11'),(5,1,'2017-12-12 09:06:11'),(3,1,'2017-12-12 09:07:11'),(5,1,'2017-12-12 09:07:11'),(3,1,'2017-12-12 09:08:11'),(5,1,'2017-12-12 09:08:11'),(3,1,'2017-12-12 09:09:11'),(5,1,'2017-12-12 09:09:11'),(3,1,'2017-12-12 09:10:11'),(5,1,'2017-12-12 09:10:11'),(3,1,'2017-12-12 09:11:11'),(5,1,'2017-12-12 09:11:11'),(3,1,'2017-12-12 09:12:11'),(5,1,'2017-12-12 09:12:11'),(3,1,'2017-12-12 09:13:11'),(5,1,'2017-12-12 09:13:11'),(3,1,'2017-12-12 09:14:11'),(5,1,'2017-12-12 09:14:11'),(3,1,'2017-12-12 09:15:11'),(5,1,'2017-12-12 09:15:11'),(3,1,'2017-12-12 09:16:11'),(5,1,'2017-12-12 09:16:11'),(3,1,'2017-12-12 09:17:11'),(5,1,'2017-12-12 09:17:11'),(3,1,'2017-12-12 09:18:11'),(5,1,'2017-12-12 09:18:11'),(3,1,'2017-12-12 09:19:11'),(5,1,'2017-12-12 09:19:11'),(3,1,'2017-12-12 09:20:11'),(5,1,'2017-12-12 09:20:11'),(3,1,'2017-12-12 09:21:11'),(5,1,'2017-12-12 09:21:11'),(3,1,'2017-12-12 09:22:11'),(5,1,'2017-12-12 09:22:11'),(3,1,'2017-12-12 09:23:11'),(5,1,'2017-12-12 09:23:11'),(3,1,'2017-12-12 09:24:11'),(5,1,'2017-12-12 09:24:11'),(3,1,'2017-12-12 09:25:11'),(5,1,'2017-12-12 09:25:11'),(3,1,'2017-12-12 09:26:11'),(5,1,'2017-12-12 09:26:11'),(3,1,'2017-12-12 09:27:11'),(5,1,'2017-12-12 09:27:11'),(3,1,'2017-12-12 09:28:11'),(5,1,'2017-12-12 09:28:11'),(3,1,'2017-12-12 09:29:11'),(5,1,'2017-12-12 09:29:11'),(3,1,'2017-12-12 09:30:11'),(5,1,'2017-12-12 09:30:11'),(3,1,'2017-12-12 09:31:11'),(5,1,'2017-12-12 09:31:11'),(3,1,'2017-12-12 09:32:11'),(5,1,'2017-12-12 09:32:11'),(3,1,'2017-12-12 09:33:11'),(5,1,'2017-12-12 09:33:11'),(3,1,'2017-12-12 09:34:11'),(5,1,'2017-12-12 09:34:11'),(3,1,'2017-12-12 09:35:11'),(5,1,'2017-12-12 09:35:11'),(3,1,'2017-12-12 09:36:11'),(5,1,'2017-12-12 09:36:11'),(3,1,'2017-12-12 09:37:11'),(5,1,'2017-12-12 09:37:11'),(3,1,'2017-12-12 09:38:11'),(5,1,'2017-12-12 09:38:11'),(3,1,'2017-12-12 09:39:11'),(5,1,'2017-12-12 09:39:11'),(3,1,'2017-12-12 09:40:11'),(5,1,'2017-12-12 09:40:11'),(3,1,'2017-12-12 09:41:12'),(5,1,'2017-12-12 09:41:12'),(3,1,'2017-12-12 11:41:27'),(5,1,'2017-12-12 11:41:27'),(3,1,'2017-12-12 16:25:25'),(5,1,'2017-12-12 16:25:25'),(3,1,'2017-12-12 16:26:11'),(5,1,'2017-12-12 16:26:11'),(3,1,'2017-12-12 16:27:11'),(5,1,'2017-12-12 16:27:11'),(3,1,'2017-12-12 16:28:11'),(5,1,'2017-12-12 16:28:11'),(3,1,'2017-12-12 16:29:11'),(5,1,'2017-12-12 16:29:11'),(3,1,'2017-12-12 16:30:11'),(5,1,'2017-12-12 16:30:11'),(3,1,'2017-12-12 16:31:11'),(5,1,'2017-12-12 16:31:11'),(3,1,'2017-12-12 16:32:11'),(5,1,'2017-12-12 16:32:11'),(3,1,'2017-12-12 16:33:11'),(5,1,'2017-12-12 16:33:11'),(3,1,'2017-12-12 16:34:11'),(5,1,'2017-12-12 16:34:11'),(3,1,'2017-12-12 16:35:11'),(5,1,'2017-12-12 16:35:11'),(3,1,'2017-12-12 16:36:11'),(5,1,'2017-12-12 16:36:11'),(3,1,'2017-12-12 16:37:11'),(5,1,'2017-12-12 16:37:11'),(3,1,'2017-12-12 16:38:11'),(5,1,'2017-12-12 16:38:11'),(3,1,'2017-12-12 16:39:11'),(5,1,'2017-12-12 16:39:11'),(3,1,'2017-12-12 16:40:11'),(5,1,'2017-12-12 16:40:11'),(3,1,'2017-12-12 16:41:11'),(5,1,'2017-12-12 16:41:11'),(3,1,'2017-12-12 16:42:11'),(5,1,'2017-12-12 16:42:11'),(3,1,'2017-12-12 16:43:11'),(5,1,'2017-12-12 16:43:11'),(3,1,'2017-12-12 16:44:11'),(5,1,'2017-12-12 16:44:11'),(3,1,'2017-12-12 16:45:11'),(5,1,'2017-12-12 16:45:11'),(3,1,'2017-12-12 16:46:11'),(5,1,'2017-12-12 16:46:11'),(3,1,'2017-12-12 16:47:11'),(5,1,'2017-12-12 16:47:11'),(3,1,'2017-12-12 16:48:11'),(5,1,'2017-12-12 16:48:11'),(3,1,'2017-12-12 16:49:11'),(5,1,'2017-12-12 16:49:11'),(3,1,'2017-12-12 16:50:11'),(5,1,'2017-12-12 16:50:11'),(3,1,'2017-12-12 16:51:11'),(5,1,'2017-12-12 16:51:11'),(3,1,'2017-12-12 16:52:11'),(5,1,'2017-12-12 16:52:11'),(3,1,'2017-12-12 16:53:11'),(5,1,'2017-12-12 16:53:11'),(3,1,'2017-12-12 16:54:11'),(5,1,'2017-12-12 16:54:11'),(3,1,'2017-12-12 16:55:11'),(5,1,'2017-12-12 16:55:11'),(3,1,'2017-12-12 16:56:11'),(5,1,'2017-12-12 16:56:11'),(3,1,'2017-12-12 16:57:11'),(5,1,'2017-12-12 16:57:11'),(3,1,'2017-12-12 16:58:11'),(5,1,'2017-12-12 16:58:11'),(3,1,'2017-12-12 16:59:11'),(5,1,'2017-12-12 16:59:11'),(3,1,'2017-12-12 17:00:11'),(5,1,'2017-12-12 17:00:11'),(3,1,'2017-12-12 17:01:11'),(5,1,'2017-12-12 17:01:11'),(3,1,'2017-12-12 17:02:11'),(5,1,'2017-12-12 17:02:11'),(3,1,'2017-12-12 17:03:11'),(5,1,'2017-12-12 17:03:11'),(3,1,'2017-12-12 17:04:11'),(5,1,'2017-12-12 17:04:11'),(3,1,'2017-12-12 17:05:11'),(5,1,'2017-12-12 17:05:11'),(3,1,'2017-12-12 17:06:11'),(5,1,'2017-12-12 17:06:11'),(3,1,'2017-12-12 17:07:11'),(5,1,'2017-12-12 17:07:11'),(3,1,'2017-12-12 17:08:11'),(5,1,'2017-12-12 17:08:11'),(3,1,'2017-12-12 17:09:11'),(5,1,'2017-12-12 17:09:11'),(3,1,'2017-12-12 17:10:11'),(5,1,'2017-12-12 17:10:11'),(3,1,'2017-12-12 17:11:11'),(5,1,'2017-12-12 17:11:11'),(3,1,'2017-12-12 17:12:11'),(5,1,'2017-12-12 17:12:11'),(3,1,'2017-12-12 17:13:11'),(5,1,'2017-12-12 17:13:11'),(3,1,'2017-12-12 17:14:11'),(5,1,'2017-12-12 17:14:11'),(3,1,'2017-12-12 17:15:11'),(5,1,'2017-12-12 17:15:11'),(3,1,'2017-12-12 17:16:11'),(5,1,'2017-12-12 17:16:11'),(3,1,'2017-12-12 17:17:11'),(5,1,'2017-12-12 17:17:11'),(3,1,'2017-12-12 17:18:11'),(5,1,'2017-12-12 17:18:11'),(3,1,'2017-12-12 17:19:11'),(5,1,'2017-12-12 17:19:11'),(3,1,'2017-12-12 17:20:11'),(5,1,'2017-12-12 17:20:11'),(3,1,'2017-12-12 17:21:11'),(5,1,'2017-12-12 17:21:11'),(3,1,'2017-12-12 17:22:11'),(5,1,'2017-12-12 17:22:11'),(3,1,'2017-12-12 17:23:11'),(5,1,'2017-12-12 17:23:11'),(3,1,'2017-12-12 17:24:11'),(5,1,'2017-12-12 17:24:11'),(3,1,'2017-12-12 17:25:11'),(5,1,'2017-12-12 17:25:11'),(3,1,'2017-12-12 17:26:11'),(5,1,'2017-12-12 17:26:11'),(3,1,'2017-12-12 17:27:11'),(5,1,'2017-12-12 17:27:11'),(3,1,'2017-12-12 17:28:11'),(5,1,'2017-12-12 17:28:11'),(3,1,'2017-12-12 17:29:11'),(5,1,'2017-12-12 17:29:11'),(3,1,'2017-12-12 17:30:11'),(5,1,'2017-12-12 17:30:11'),(3,1,'2017-12-12 17:31:11'),(5,1,'2017-12-12 17:31:11'),(3,1,'2017-12-12 17:32:11'),(5,1,'2017-12-12 17:32:11'),(3,1,'2017-12-12 17:33:11'),(5,1,'2017-12-12 17:33:11'),(3,1,'2017-12-12 17:34:11'),(5,1,'2017-12-12 17:34:11'),(3,1,'2017-12-12 17:35:11'),(5,1,'2017-12-12 17:35:11'),(3,1,'2017-12-12 17:36:11'),(5,1,'2017-12-12 17:36:11'),(3,1,'2017-12-12 17:37:11'),(5,1,'2017-12-12 17:37:11'),(3,1,'2017-12-12 17:38:11'),(5,1,'2017-12-12 17:38:11'),(3,1,'2017-12-12 17:39:11'),(5,1,'2017-12-12 17:39:11'),(3,1,'2017-12-12 17:40:11'),(5,1,'2017-12-12 17:40:11'),(3,1,'2017-12-12 17:41:11'),(5,1,'2017-12-12 17:41:11'),(3,1,'2017-12-12 17:42:11'),(5,1,'2017-12-12 17:42:11'),(3,1,'2017-12-12 17:43:11'),(5,1,'2017-12-12 17:43:11'),(3,1,'2017-12-12 17:44:11'),(5,1,'2017-12-12 17:44:11'),(3,1,'2017-12-12 17:45:12'),(5,1,'2017-12-12 17:45:12'),(3,1,'2017-12-12 17:46:11'),(5,1,'2017-12-12 17:46:11'),(3,1,'2017-12-12 17:47:11'),(5,1,'2017-12-12 17:47:11'),(3,1,'2017-12-12 17:48:11'),(5,1,'2017-12-12 17:48:11'),(3,1,'2017-12-12 17:49:11'),(5,1,'2017-12-12 17:49:11'),(3,1,'2017-12-12 17:50:11'),(5,1,'2017-12-12 17:50:11'),(3,1,'2017-12-12 17:51:11'),(5,1,'2017-12-12 17:51:11'),(3,1,'2017-12-12 17:52:11'),(5,1,'2017-12-12 17:52:11'),(3,1,'2017-12-12 17:53:11'),(5,1,'2017-12-12 17:53:11'),(3,1,'2017-12-12 17:54:11'),(5,1,'2017-12-12 17:54:11'),(3,1,'2017-12-12 17:55:11'),(5,1,'2017-12-12 17:55:11'),(3,1,'2017-12-12 17:56:11'),(5,1,'2017-12-12 17:56:11'),(3,1,'2017-12-12 17:57:11'),(5,1,'2017-12-12 17:57:11'),(3,1,'2017-12-12 17:58:11'),(5,1,'2017-12-12 17:58:11'),(3,1,'2017-12-12 17:59:11'),(5,1,'2017-12-12 17:59:11'),(3,1,'2017-12-12 18:00:11'),(5,1,'2017-12-12 18:00:11'),(3,1,'2017-12-12 18:01:11'),(5,1,'2017-12-12 18:01:11'),(3,1,'2017-12-12 18:02:11'),(5,1,'2017-12-12 18:02:11'),(3,1,'2017-12-12 18:03:11'),(5,1,'2017-12-12 18:03:11'),(3,1,'2017-12-12 18:04:11'),(5,1,'2017-12-12 18:04:11'),(3,1,'2017-12-12 18:05:11'),(5,1,'2017-12-12 18:05:11'),(3,1,'2017-12-12 18:06:11'),(5,1,'2017-12-12 18:06:11'),(3,1,'2017-12-12 18:07:11'),(5,1,'2017-12-12 18:07:11'),(3,1,'2017-12-12 18:08:11'),(5,1,'2017-12-12 18:08:11'),(3,1,'2017-12-12 18:09:11'),(5,1,'2017-12-12 18:09:11'),(3,1,'2017-12-12 18:10:11'),(5,1,'2017-12-12 18:10:11'),(3,1,'2017-12-12 18:11:11'),(5,1,'2017-12-12 18:11:11'),(3,1,'2017-12-12 18:12:11'),(5,1,'2017-12-12 18:12:11'),(3,1,'2017-12-12 18:13:11'),(5,1,'2017-12-12 18:13:11'),(3,1,'2017-12-12 18:14:11'),(5,1,'2017-12-12 18:14:11'),(3,1,'2017-12-12 18:15:11'),(5,1,'2017-12-12 18:15:11'),(3,1,'2017-12-12 18:16:11'),(5,1,'2017-12-12 18:16:11'),(3,1,'2017-12-12 18:17:11'),(5,1,'2017-12-12 18:17:11'),(3,1,'2017-12-12 18:18:11'),(5,1,'2017-12-12 18:18:11'),(3,1,'2017-12-12 18:19:11'),(5,1,'2017-12-12 18:19:11'),(3,1,'2017-12-12 18:20:11'),(5,1,'2017-12-12 18:20:11'),(3,1,'2017-12-12 18:21:11'),(5,3,'2017-12-12 18:21:11'),(5,1,'2017-12-12 18:26:11'),(5,1,'2017-12-12 18:27:11'),(5,1,'2017-12-12 18:28:11'),(5,1,'2017-12-12 18:29:11'),(5,1,'2017-12-12 18:30:11'),(5,1,'2017-12-12 18:31:11'),(5,1,'2017-12-12 18:32:11'),(5,1,'2017-12-12 18:33:11'),(5,1,'2017-12-12 18:34:11'),(5,1,'2017-12-12 18:35:11'),(5,1,'2017-12-12 18:36:11'),(5,1,'2017-12-12 18:37:11'),(5,1,'2017-12-12 18:38:11'),(5,1,'2017-12-12 18:39:11'),(5,1,'2017-12-12 18:40:11'),(5,1,'2017-12-12 18:41:11'),(5,1,'2017-12-12 18:42:11'),(5,1,'2017-12-12 18:43:11'),(5,1,'2017-12-12 18:44:11'),(5,1,'2017-12-12 18:45:11'),(5,1,'2017-12-12 18:46:11'),(5,1,'2017-12-12 18:47:11'),(5,1,'2017-12-12 18:48:11'),(5,1,'2017-12-12 18:49:11'),(5,1,'2017-12-12 18:50:11'),(5,1,'2017-12-12 18:51:11'),(5,1,'2017-12-12 18:52:11'),(5,1,'2017-12-12 18:53:11'),(5,1,'2017-12-12 18:54:11');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passenger` (
  `full_name` varchar(50) NOT NULL,
  `mobile_number` int(11) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  PRIMARY KEY (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger`
--

LOCK TABLES `passenger` WRITE;
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
INSERT INTO `passenger` VALUES ('Allistair Jones',2147483647,'augue.id@in.ca','9081 Magna Av.','Palma de Mallorca','BA','Female','1990-01-16'),('Sylvester Neal',2147483647,'augue@Donectempor.com','Ap #735-3277 Mollis St.','Des Moines','Iowa','Female','1996-01-16'),('Cyrus Mosley',2147483647,'diam.lorem.auctor@magna.org','P.O. Box 700, 2183 Eget Av.','Täby','AB','Male','1993-08-08'),('Caldwell Landry',2147483647,'Integer.urna@hendreritidante.com','715-6919 Facilisis. Avenue','San José de Maipo','RM','Male','1958-08-30'),('Beau Kane',2147483647,'ligula.Donec.luctus@porttitortellusnon.co.uk','9561 Ultricies Rd.','Saint-Étienne-du-Rouvray','Haute-Normandie','Female','2000-01-07'),('Aladdin Nixon',2147483647,'mollis@justofaucibuslectus.com','379 Diam St.','Lo Prado','Metropolitana de Santiago','Female','1917-05-24'),('Rohan Naik',769095180,'naikrohan2311@gmail.com','75 St.Alphonsus','Boston','MA','Male','1993-11-13'),('Tucker Pitts',2147483647,'ornare.egestas@enimEtiamimperdiet.edu','531-766 In St.','Timaru','South Island','Female','1960-05-08'),('Gage Harrell',2147483647,'sed.sapien@liberoDonec.net','Ap #863-8574 Et, Street','Opgrimbie','L.','Female','2000-08-22'),('Francis Crawford',1240196722,'tellus.Aenean.egestas@justonecante.net','3876 Auctor St.','Galway','C','Female','2001-05-16'),('Amos Lawson',2147483647,'urna@euismodest.co.uk','P.O. Box 517, 6287 Morbi Road','Alcobendas','Madrid','Female','1999-10-16');
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_passenger before insert on passenger
for each row
begin
 IF (NEW.mobile_number REGEXP '^-?[0-9]+$' ) = 0 THEN 
  SIGNAL SQLSTATE '12345'
     SET MESSAGE_TEXT = 'Invalid Input';
END IF; 
	IF NOT (New.email_id REGEXP '^[a-z0-9](\.?[a-z0-9]){5,}@g(oogle)?mail\.com$' ) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Wrong email';
	END IF;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `passenger_track_using_pnr`
--

DROP TABLE IF EXISTS `passenger_track_using_pnr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passenger_track_using_pnr` (
  `PNR` varchar(20) NOT NULL,
  `coach_number` varchar(5) NOT NULL,
  `Passenger_name` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `train_id` int(11) NOT NULL,
  PRIMARY KEY (`PNR`),
  KEY `train_id` (`train_id`),
  CONSTRAINT `passenger_track_using_pnr_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `train` (`train_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger_track_using_pnr`
--

LOCK TABLES `passenger_track_using_pnr` WRITE;
/*!40000 ALTER TABLE `passenger_track_using_pnr` DISABLE KEYS */;
INSERT INTO `passenger_track_using_pnr` VALUES ('7MESYO','S33','Allistair Jones','Female',5);
/*!40000 ALTER TABLE `passenger_track_using_pnr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `railway_earnings`
--

DROP TABLE IF EXISTS `railway_earnings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `railway_earnings` (
  `zone` varchar(45) DEFAULT NULL,
  `train_id` int(11) NOT NULL,
  `class_type` varchar(50) DEFAULT NULL,
  `fare` int(11) DEFAULT NULL,
  PRIMARY KEY (`train_id`),
  CONSTRAINT `fk_earnings` FOREIGN KEY (`train_id`) REFERENCES `tickets` (`train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `railway_earnings`
--

LOCK TABLES `railway_earnings` WRITE;
/*!40000 ALTER TABLE `railway_earnings` DISABLE KEYS */;
/*!40000 ALTER TABLE `railway_earnings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `railway_zones`
--

DROP TABLE IF EXISTS `railway_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `railway_zones` (
  `zone_id` int(11) NOT NULL,
  `zone_name` varchar(45) NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `railway_zones`
--

LOCK TABLES `railway_zones` WRITE;
/*!40000 ALTER TABLE `railway_zones` DISABLE KEYS */;
INSERT INTO `railway_zones` VALUES (1,'south'),(2,'north'),(3,'west'),(4,'east');
/*!40000 ALTER TABLE `railway_zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_railway_zones before insert on railway_zones
for each row
begin
 if new.zone_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `repairs_supervisor`
--

DROP TABLE IF EXISTS `repairs_supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repairs_supervisor` (
  `supervisor_id` int(11) NOT NULL,
  `supervisor_name` varchar(45) NOT NULL,
  `supervisor_department` varchar(45) NOT NULL,
  `supervisor_zone` varchar(45) NOT NULL,
  `department_department_id` int(11) NOT NULL,
  PRIMARY KEY (`supervisor_id`,`department_department_id`),
  KEY `fk_repairs_supervisor_department1_idx` (`department_department_id`),
  CONSTRAINT `fk_repairs_supervisor_department1` FOREIGN KEY (`department_department_id`) REFERENCES `department` (`department_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repairs_supervisor`
--

LOCK TABLES `repairs_supervisor` WRITE;
/*!40000 ALTER TABLE `repairs_supervisor` DISABLE KEYS */;
INSERT INTO `repairs_supervisor` VALUES (1,'Ralph Charles','Repairs','east',3),(2,'Chaim Carrillo','maintenance','south',3),(3,'Nicholas Maddox','Repairs','north',1),(4,'Grady Lester','Manufacturing','east',4),(5,'Burton Joyce','Repairs','north',3),(6,'Simon Carroll','Repairs','west',1),(7,'Allen Moore','Field Services','east',2),(8,'Hayes Farmer','maintenance','west',1),(9,'Zachary Bernard','Field Services','east',2),(10,'Brent Mcfadden','Repairs','north',2);
/*!40000 ALTER TABLE `repairs_supervisor` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_repairs_supervisor before insert on repairs_supervisor
for each row
begin
 if new.supervisor_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `reservation_status`
--

DROP TABLE IF EXISTS `reservation_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation_status` (
  `train_id` int(11) NOT NULL,
  `available_date` varchar(20) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `PNR` varchar(20) NOT NULL,
  `reservation_date` date NOT NULL,
  `reservation_status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`train_id`,`available_date`,`email_id`,`PNR`),
  KEY `email_id` (`email_id`),
  CONSTRAINT `reservation_status_ibfk_1` FOREIGN KEY (`train_id`, `available_date`) REFERENCES `train_booking_status` (`train_id`, `available_date`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reservation_status_ibfk_2` FOREIGN KEY (`email_id`) REFERENCES `passenger` (`email_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_status`
--

LOCK TABLES `reservation_status` WRITE;
/*!40000 ALTER TABLE `reservation_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `Source` varchar(45) DEFAULT NULL,
  `Destination` varchar(45) DEFAULT NULL,
  `Number_of_stops` int(11) DEFAULT NULL,
  `Total_Distance` int(11) DEFAULT NULL,
  `Total_Journey_Time` time DEFAULT NULL,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,'Pune','Hyderabad',10,200,'09:15:40'),(2,'Goa','Chruchgate',15,500,'08:15:40'),(3,'Mumbai','Hyderabad',20,800,'15:15:40'),(4,'Goa','Punjab',30,1200,'22:15:40'),(5,'Bandra','Howrah',21,2300,'22:15:40'),(6,'Bandra','Howrah',15,2000,'15:15:40'),(7,'Howrah','Surat',20,2100,'18:15:40'),(8,'Hyderabad','Bangalore',10,500,'09:15:40'),(9,'Hyderabad','Delhi',20,2200,'20:15:40'),(10,'Bangalore','Chruchgate',15,900,'21:15:40'),(11,'Mumbai','Delhi',25,2500,'22:15:40');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `station` (
  `station_id` int(11) NOT NULL,
  `station_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`station_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES (1,'Chruchgate'),(2,'Goa'),(3,'Surat'),(4,'Howrah'),(5,'Pune'),(6,'Hyderabad'),(7,'Delhi'),(8,'Punjab'),(9,'Bangalore'),(10,'Bandra'),(11,'Mumbai'),(12,'Thane');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_station before insert on station
for each row
begin
 if new.station_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `PNR` varchar(20) NOT NULL,
  `source_station_name` varchar(20) NOT NULL,
  `destination_station_name` varchar(20) NOT NULL,
  `ticket_status` varchar(10) NOT NULL,
  `train_id` int(11) NOT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `class_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`PNR`,`train_id`),
  KEY `train_id` (`train_id`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `train` (`train_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `railway_operations_management`.`ticket_AFTER_INSERT` AFTER INSERT ON `ticket` FOR EACH ROW
BEGIN
declare message varchar(100);
set message = 'Your Ticket is Booked successfully.' ;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `time_table_for_station`
--

DROP TABLE IF EXISTS `time_table_for_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_table_for_station` (
  `train_id` int(11) NOT NULL,
  `train_timings` time NOT NULL,
  `station_station_id` int(11) NOT NULL,
  PRIMARY KEY (`train_id`,`station_station_id`),
  KEY `fk_time_table_for_station_station1_idx` (`station_station_id`),
  CONSTRAINT `fk_time_table_for_station_station1` FOREIGN KEY (`station_station_id`) REFERENCES `station` (`station_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_table_for_station`
--

LOCK TABLES `time_table_for_station` WRITE;
/*!40000 ALTER TABLE `time_table_for_station` DISABLE KEYS */;
INSERT INTO `time_table_for_station` VALUES (1,'08:51:05',1),(1,'14:51:15',2),(1,'11:46:17',3),(1,'21:16:59',4),(1,'11:14:40',5),(1,'08:46:25',7),(1,'09:30:40',8),(1,'23:03:48',9),(2,'03:08:58',1),(2,'19:31:06',2),(2,'07:36:54',3),(2,'09:50:00',9),(2,'07:07:33',10),(3,'02:23:08',1),(3,'03:07:34',2),(3,'08:01:06',3),(3,'13:01:55',4),(3,'07:26:52',5),(3,'06:44:12',6),(3,'00:49:10',7),(3,'03:34:52',8),(3,'11:43:58',9),(3,'10:59:48',10),(4,'11:36:48',2),(4,'19:14:20',3),(4,'20:56:39',4),(4,'06:24:11',6),(4,'07:14:22',7),(4,'12:46:00',8),(4,'20:52:37',10),(5,'21:46:41',1),(5,'06:53:13',2),(5,'02:55:00',3),(5,'07:25:07',4),(5,'07:22:22',5),(5,'10:52:11',6),(5,'18:51:23',7),(5,'08:27:48',9),(5,'23:01:01',10),(6,'07:30:51',3),(6,'13:45:42',6),(6,'02:37:41',7),(6,'09:55:41',8),(7,'02:13:52',1),(7,'19:24:49',2),(7,'13:35:29',3),(7,'02:25:30',4),(7,'20:36:27',7),(7,'20:56:15',8),(7,'09:43:31',9),(7,'13:53:46',10),(8,'04:10:16',1),(8,'19:25:10',2),(8,'21:06:32',4),(8,'10:46:48',6),(8,'16:36:23',7),(8,'18:17:32',10),(9,'19:23:44',2),(9,'22:29:41',3),(9,'00:45:34',4),(9,'23:44:38',8),(9,'18:38:38',10),(10,'06:50:44',4),(10,'13:11:10',5),(10,'00:37:00',7),(10,'19:05:34',8),(10,'14:48:28',9);
/*!40000 ALTER TABLE `time_table_for_station` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `train`
--

DROP TABLE IF EXISTS `train`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train` (
  `train_id` int(11) NOT NULL AUTO_INCREMENT,
  `train_name` varchar(50) NOT NULL,
  `train_type` varchar(50) NOT NULL,
  `orignating_station` varchar(50) DEFAULT NULL,
  `destination_station` varchar(50) DEFAULT NULL,
  `train_class_type_train_id` int(11) DEFAULT NULL,
  `train_schedule_train_id` int(11) DEFAULT NULL,
  `route_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`train_id`),
  KEY `fk_train_train_class_type1_idx` (`train_class_type_train_id`),
  KEY `fk_train_train_schedule1_idx` (`train_schedule_train_id`),
  CONSTRAINT `fk_train_train_class_type1` FOREIGN KEY (`train_class_type_train_id`) REFERENCES `train_class_type` (`train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_train_train_schedule1` FOREIGN KEY (`train_schedule_train_id`) REFERENCES `train_schedule` (`train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train`
--

LOCK TABLES `train` WRITE;
/*!40000 ALTER TABLE `train` DISABLE KEYS */;
INSERT INTO `train` VALUES (1,'Shatabdi Express','Express','Pune','Hyderabad',10,7,1),(2,'August Kranti Express','Duronto','Goa','Chruchgate',2,7,2),(3,'Jammu Tawi Express','Super Fast','Mumbai','Hyderabad',4,7,3),(4,'Deccan Express','Express','Goa','Punjab',5,3,4),(5,'Mumbai Mail','Shatabdi','Bandra','Howrah',4,7,5),(6,'Udyan Express','Super Fast','Bandra','Howrah',10,5,6),(7,'Chennai Mail','Duronto','Howrah','Surat',10,10,7),(8,'East Express','Shatabdi','Hyderabad','Bangalore',7,9,8),(9,'West Express','Super Fast','Hyderabad','Delhi',6,10,9),(10,'North Express','Super Fast','Bangalore','Chruchgate',8,5,10),(11,'Pawan Express','Express','Mumbai','Delhi',NULL,NULL,11);
/*!40000 ALTER TABLE `train` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_train before insert on train
for each row
begin
declare message_text varchar(50);
 if new.train_name = '' THEN
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT = 'Train_Name cannot be blank';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `train_booking_status`
--

DROP TABLE IF EXISTS `train_booking_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_booking_status` (
  `train_id` int(11) NOT NULL,
  `available_date` varchar(20) NOT NULL,
  `seat_booked_status` int(11) DEFAULT NULL,
  `available_seat_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`train_id`,`available_date`),
  CONSTRAINT `train_booking_status_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `train` (`train_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_booking_status`
--

LOCK TABLES `train_booking_status` WRITE;
/*!40000 ALTER TABLE `train_booking_status` DISABLE KEYS */;
INSERT INTO `train_booking_status` VALUES (1,'2017-12-01',0,50),(2,'2017-12-01',0,100),(3,'2017-12-01',0,200),(4,'2017-12-01',0,5),(5,'2017-12-01',0,50),(6,'2017-12-04',0,60),(7,'2017-12-04',0,30),(8,'2017-12-04',0,40),(9,'2017-12-04',0,10),(10,'2017-12-04',0,50);
/*!40000 ALTER TABLE `train_booking_status` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_train_booking_status before insert on train_booking_status
for each row
begin
 if new.train_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `train_class_type`
--

DROP TABLE IF EXISTS `train_class_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_class_type` (
  `train_id` int(11) NOT NULL,
  `class_type1` varchar(10) NOT NULL,
  `fare_type1` float NOT NULL,
  `class_type2` varchar(10) NOT NULL,
  `fare_type2` float NOT NULL,
  `class_type3` varchar(10) NOT NULL,
  `fare_type3` float NOT NULL,
  PRIMARY KEY (`train_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_class_type`
--

LOCK TABLES `train_class_type` WRITE;
/*!40000 ALTER TABLE `train_class_type` DISABLE KEYS */;
INSERT INTO `train_class_type` VALUES (1,'First Clas',100,'Business C',200,'Second Cla',300),(2,'First Clas',200,'Business C',300,'Second Cla',400),(3,'First Clas',500,'Business C',600,'Second Cla',700),(4,'First Clas',800,'Business C',900,'Second Cla',1000),(5,'First Clas',4000,'Business C',5000,'Second Cla',6000),(6,'First Clas',500,'Business C',800,'Second Cla',900),(7,'First Clas',400,'Business C',600,'Second Cla',800),(8,'First Clas',8000,'Business C',9000,'Second Cla',7000),(9,'First Clas',700,'Business C',800,'Second Cla',900),(10,'First Clas',500,'Business C',600,'Second Cla',700);
/*!40000 ALTER TABLE `train_class_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_train_class_type before insert on train_class_type
for each row
begin
 if new.train_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `train_repairs`
--

DROP TABLE IF EXISTS `train_repairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_repairs` (
  `repairs_id` int(11) NOT NULL,
  `repirs_type` varchar(45) NOT NULL,
  `repairs_cost` float NOT NULL,
  `repairs_zone` varchar(45) NOT NULL,
  `repairs_supervisor` varchar(45) NOT NULL,
  `train_train_id` int(11) NOT NULL,
  `train_train_class_type_train_id` int(11) NOT NULL,
  `train_train_schedule_train_id` int(11) NOT NULL,
  `repairs_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`repairs_id`,`train_train_id`,`train_train_class_type_train_id`,`train_train_schedule_train_id`),
  KEY `fk_train_repairs_train1_idx` (`train_train_id`,`train_train_class_type_train_id`,`train_train_schedule_train_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_repairs`
--

LOCK TABLES `train_repairs` WRITE;
/*!40000 ALTER TABLE `train_repairs` DISABLE KEYS */;
INSERT INTO `train_repairs` VALUES (109,'Side Lifting',1731,'North','Grady Lester',3,3,3,'Completed'),(119,'Painting',1313,'West','Simon Carroll',9,9,9,'Completed'),(121,'Side Lifting',1802,'West','Burton Joyce',7,7,7,NULL),(127,'Rail sleepers replacement',1049,'East','Brent Mcfadden',2,2,2,'Completed'),(136,'Side Lifting',1541,'North','Grady Lester',4,4,4,NULL),(141,'Side Lifting',1676,'West','Ralph Charles',5,5,5,'Completed'),(178,'Wheels replacement',1619,'East','Nicholas Maddox',6,6,6,'Completed'),(182,'Rail Align',1265,'North','Brent Mcfadden',1,1,1,NULL),(185,'Side Lifting',1171,'West','Simon Carroll',8,8,8,NULL),(197,'Rail Align',1288,'West','Chaim Carrillo',10,10,10,NULL);
/*!40000 ALTER TABLE `train_repairs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_train_repairs before insert on train_repairs
for each row
begin
 if new.repairs_id = '' then
 signal sqlstate '45000';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `train_repairs_has_railway_zones`
--

DROP TABLE IF EXISTS `train_repairs_has_railway_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_repairs_has_railway_zones` (
  `train_repairs_repairs_id` int(11) NOT NULL,
  `train_repairs_train_train_id` int(11) NOT NULL,
  `train_repairs_train_train_class_type_train_id` int(11) NOT NULL,
  `train_repairs_train_train_schedule_train_id` int(11) NOT NULL,
  `railway_zones_zone_id` int(11) NOT NULL,
  `zonal_manager` varchar(45) NOT NULL,
  `zonal_HQ` varchar(45) NOT NULL,
  PRIMARY KEY (`train_repairs_repairs_id`,`train_repairs_train_train_id`,`train_repairs_train_train_class_type_train_id`,`train_repairs_train_train_schedule_train_id`,`railway_zones_zone_id`),
  KEY `fk_train_repairs_has_railway_zones_railway_zones1_idx` (`railway_zones_zone_id`),
  KEY `fk_train_repairs_has_railway_zones_train_repairs1_idx` (`train_repairs_repairs_id`,`train_repairs_train_train_id`,`train_repairs_train_train_class_type_train_id`,`train_repairs_train_train_schedule_train_id`),
  CONSTRAINT `fk_train_repairs_has_railway_zones_railway_zones1` FOREIGN KEY (`railway_zones_zone_id`) REFERENCES `railway_zones` (`zone_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_train_repairs_has_railway_zones_train_repairs1` FOREIGN KEY (`train_repairs_repairs_id`, `train_repairs_train_train_id`, `train_repairs_train_train_class_type_train_id`, `train_repairs_train_train_schedule_train_id`) REFERENCES `train_repairs` (`repairs_id`, `train_train_id`, `train_train_class_type_train_id`, `train_train_schedule_train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_repairs_has_railway_zones`
--

LOCK TABLES `train_repairs_has_railway_zones` WRITE;
/*!40000 ALTER TABLE `train_repairs_has_railway_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `train_repairs_has_railway_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `train_repairs_has_repairs_supervisor`
--

DROP TABLE IF EXISTS `train_repairs_has_repairs_supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_repairs_has_repairs_supervisor` (
  `train_repairs_repairs_id` int(11) NOT NULL,
  `train_repairs_train_train_id` int(11) NOT NULL,
  `train_repairs_train_train_class_type_train_id` int(11) NOT NULL,
  `train_repairs_train_train_schedule_train_id` int(11) NOT NULL,
  `repairs_supervisor_supervisor_id` int(11) NOT NULL,
  PRIMARY KEY (`train_repairs_repairs_id`,`train_repairs_train_train_id`,`train_repairs_train_train_class_type_train_id`,`train_repairs_train_train_schedule_train_id`,`repairs_supervisor_supervisor_id`),
  KEY `fk_train_repairs_has_repairs_supervisor_repairs_supervisor1_idx` (`repairs_supervisor_supervisor_id`),
  KEY `fk_train_repairs_has_repairs_supervisor_train_repairs1_idx` (`train_repairs_repairs_id`,`train_repairs_train_train_id`,`train_repairs_train_train_class_type_train_id`,`train_repairs_train_train_schedule_train_id`),
  CONSTRAINT `fk_train_repairs_has_repairs_supervisor_repairs_supervisor1` FOREIGN KEY (`repairs_supervisor_supervisor_id`) REFERENCES `repairs_supervisor` (`supervisor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_train_repairs_has_repairs_supervisor_train_repairs1` FOREIGN KEY (`train_repairs_repairs_id`, `train_repairs_train_train_id`, `train_repairs_train_train_class_type_train_id`, `train_repairs_train_train_schedule_train_id`) REFERENCES `train_repairs` (`repairs_id`, `train_train_id`, `train_train_class_type_train_id`, `train_train_schedule_train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_repairs_has_repairs_supervisor`
--

LOCK TABLES `train_repairs_has_repairs_supervisor` WRITE;
/*!40000 ALTER TABLE `train_repairs_has_repairs_supervisor` DISABLE KEYS */;
/*!40000 ALTER TABLE `train_repairs_has_repairs_supervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `train_repairs_status_tracking`
--

DROP TABLE IF EXISTS `train_repairs_status_tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_repairs_status_tracking` (
  `train_name` varchar(20) NOT NULL,
  `repairs_id` int(11) NOT NULL,
  `repirs_type` varchar(45) NOT NULL,
  `repairs_cost` float NOT NULL,
  `repairs_zone` varchar(45) NOT NULL,
  `repairs_supervisor` varchar(45) NOT NULL,
  `train_train_id` int(11) NOT NULL,
  PRIMARY KEY (`repairs_id`),
  KEY `fk_train_repairs_tracking` (`train_train_id`),
  CONSTRAINT `fk_train_repairs_tracking` FOREIGN KEY (`train_train_id`) REFERENCES `train` (`train_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_repairs_status_tracking`
--

LOCK TABLES `train_repairs_status_tracking` WRITE;
/*!40000 ALTER TABLE `train_repairs_status_tracking` DISABLE KEYS */;
INSERT INTO `train_repairs_status_tracking` VALUES ('West Express',119,'Painting',1313,'West','Simon Carroll',9),('Mumbai Mail',141,'Side Lifting',1676,'West','Ralph Charles',5);
/*!40000 ALTER TABLE `train_repairs_status_tracking` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `railway_operations_management`.`train_repairs_status_tracking_AFTER_INSERT` AFTER INSERT ON `train_repairs_status_tracking` FOR EACH ROW
BEGIN
declare repair_stat varchar(20);
Set @repair_stat = (Select repairs_status as 'Completed' from train_repairs where train_train_id = @train_id);
##Select @repairs_status = 'Completed';
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `train_schedule`
--

DROP TABLE IF EXISTS `train_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `train_schedule` (
  `train_id` int(11) NOT NULL AUTO_INCREMENT,
  `train_name` varchar(50) NOT NULL,
  `days_running_on` varchar(10) NOT NULL,
  `start_time` time NOT NULL,
  PRIMARY KEY (`train_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train_schedule`
--

LOCK TABLES `train_schedule` WRITE;
/*!40000 ALTER TABLE `train_schedule` DISABLE KEYS */;
INSERT INTO `train_schedule` VALUES (1,'Shatabdi Express','Sunday','13:25:51'),(2,'Chennai Mail','Tuesday','12:18:58'),(3,'Mumbai Mail','Monday','02:07:17'),(4,'Deccan Express','Friday','19:54:11'),(5,'East Express','Monday','17:24:13'),(6,'North Express','Friday','10:27:20'),(7,'Jammu Tawi Express','All','23:58:58'),(8,'Udyan Express','All','16:57:03'),(9,'August Kranti Express','Friday','19:49:15'),(10,'West Express','Monday','05:23:58'),(11,'Pawan Express','Tuesday','14:15:46');
/*!40000 ALTER TABLE `train_schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger for_train_schedule before insert on train_schedule
for each row
begin
declare message_text varchar(50);
 if new.train_name = '' THEN
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT = 'Train_Name cannot be blank';
 end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `age_group_of_passenger_vw`
--

/*!50001 DROP VIEW IF EXISTS `age_group_of_passenger_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `age_group_of_passenger_vw` AS select `p`.`full_name` AS `Full_name`,`rs`.`email_id` AS `email_id`,`rs`.`PNR` AS `PNR`,`p`.`Gender` AS `Gender`,ceiling(((to_days(cast(now() as date)) - to_days(`p`.`dob`)) / 365)) AS `Age` from (`reservation_status` `rs` join `passenger` `p` on((`rs`.`email_id` = `p`.`email_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `earnings_vs_expense_vw`
--

/*!50001 DROP VIEW IF EXISTS `earnings_vs_expense_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `earnings_vs_expense_vw` AS select `tr`.`repairs_zone` AS `Zone`,sum(`fp`.`Fare`) AS `Total Earnings`,sum(`tr`.`repairs_cost`) AS `Total Expense` from (`train_repairs_status_tracking` `tr` join `fare_per_journey` `fp`) where (`tr`.`train_train_id` = `fp`.`train_id`) group by `tr`.`repairs_zone` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-12 14:11:07

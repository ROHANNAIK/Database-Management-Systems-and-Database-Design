Select * from route;

select * from station_on_route;

insert  into route values (1,'Pune', 'Hyderabad', 10, 200, '09:15:40'); 
insert  into route values (2,'Goa', 'Chruchgate', 15, 500, '08:15:40'); 
insert  into route values (3,'Mumbai', 'Hyderabad', 20, 800, '15:15:40'); 
insert  into route values (4,'Goa', 'Punjab', 30, 1200, '22:15:40'); 
insert  into route values (5,'Bandra', 'Howrah', 21, 2300, '22:15:40'); 
insert  into route values (6,'Bandra', 'Howrah', 15, 2000, '15:15:40'); 
insert  into route values (7,'Howrah', 'Surat', 20, 2100, '18:15:40'); 
insert  into route values (8,'Hyderabad', 'Bangalore', 10, 500, '09:15:40'); 
insert  into route values (9,'Hyderabad', 'Delhi', 20, 2200, '20:15:40'); 
insert  into route values (10,'Bangalore', 'Chruchgate', 15, 900, '21:15:40'); 
insert  into route values (11,'Mumbai', 'Delhi', 25, 2500, '22:15:40'); 
